import { createBrowserClient } from '@supabase/ssr';
export function supabase() {
 const url=process.env.NEXT_PUBLIC_SUPABASE_URL;
 const key=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
 if(!url||!key) throw new Error('Configure Supabase environment variables');
 return createBrowserClient(url,key);
}
